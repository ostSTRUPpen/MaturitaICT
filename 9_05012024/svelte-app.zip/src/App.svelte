<script>
	let count = 0

		function add(){
			count++
		}
</script>

    	<p>Poet:</p>
    	<div class="form">
    		<p>{count}</p>
    		<button id="add-button" on:click={add}>PYi�st</button>
    	</div>

<style>
    		p {
    			color: red;
    		}

    		.form {
    			font-size: larger;
    		}

    		#add-button {
    			rotate: 15deg;
    		}
</style>